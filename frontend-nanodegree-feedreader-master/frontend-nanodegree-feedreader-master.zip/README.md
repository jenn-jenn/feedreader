# Steps to run the application

1. Download files
2. open index.html
